/***************************** Include Files *********************************/
#include <stdio.h>
#include "xparameters.h"
#include "xgpio.h"

#include "platform.h"

/************************** Constant Definitions *****************************/

//#define LED 0xC8   /* Assumes bit 0 of GPIO is connected to an LED  */

/*
 * The following constants map to the XPAR parameters created in the
 * xparameters.h file. They are defined here such that a user can easily
 * change all the needed parameters in one place.
 */
#define GPIO_EXAMPLE_DEVICE_ID  XPAR_GPIO_0_DEVICE_ID

/*
 * The following constant is used to wait after an LED is turned on to make
 * sure that it is visible to the human eye.  This constant might need to be
 * tuned for faster or slower processor speeds.
 */
#define LED_DELAY     10000

/*
 * The following constant is used to determine which channel of the GPIO is
 * used for the LED if there are 2 channels supported.
 */
#define LED_ANODE 1
#define LED_CHARACTER 2

/**************************** Type Definitions *******************************/


/***************** Macros (Inline Functions) Definitions *********************/

#ifdef PRE_2_00A_APPLICATION

/*
 * The following macros are provided to allow an application to compile that
 * uses an older version of the driver (pre 2.00a) which did not have a channel
 * parameter. Note that the channel parameter is fixed as channel 1.
 */
#define XGpio_SetDataDirection(InstancePtr, DirectionMask) \
        XGpio_SetDataDirection(InstancePtr, LED_CHANNEL, DirectionMask)

#define XGpio_DiscreteRead(InstancePtr) \
        XGpio_DiscreteRead(InstancePtr, LED_CHANNEL)

#define XGpio_DiscreteWrite(InstancePtr, Mask) \
        XGpio_DiscreteWrite(InstancePtr, LED_CHANNEL, Mask)

#define XGpio_DiscreteSet(InstancePtr, Mask) \
        XGpio_DiscreteSet(InstancePtr, LED_CHANNEL, Mask)

#endif

/************************** Function Prototypes ******************************/


/************************** Variable Definitions *****************************/

/*
 * The following are declared globally so they are zeroed and so they are
 * easily accessible from a debugger
 */

XGpio Gpio; /* The Instance of the GPIO Driver */
XGpio Gpio1;
//Global variables declaration
//Pushed button variable
int button = 0;
//Common variables used in cycles such as While, For, conditional as If, and combined
int i, j, k;
//Variable that will receive a Chart Set with a  maximum size of 3
char Output[3];
//Encrypt and decrypt variables following Matrix and Vector model
int encrypt[3][1], decrypt[3][1], A[3][3], B[3][3], BC[3][1], C[3][3];
//This variable will save the new encrypted code after running the algorithm
int newCode = 0;

/*****************************************************************************/
/**
*
* The purpose of this function is to illustrate how to use the GPIO
* driver to turn on and off an LED.
*
* @param	None
*
* @return	XST_FAILURE to indicate that the GPIO Initialization had
*		failed.
*
* @note		This function will not return if the test is running.
*
******************************************************************************/
int display_Character(char c)
{
	#define zero 0xC0
	#define one 0xF9
	#define two 0xA4
	#define three 0xB0
	#define four 0x99
	#define five 0x92
	#define six 0x82
	#define seven 0xF8
	#define eight 0x80
	#define nine 0x90
	#define O 0xC0
	#define P 0x8C
	#define E 0x86
	#define N 0xC8
	#define R 0xCE
	int value;
	switch(c) {
	   case 'O'  :
	      //print("O \n");
	      value = O;
	      break; /* optional */
	   case 'P'  :
	      //print("P \n");
	      value = P;
	      break; /* optional */
	   case 'E'  :
	   	  //print("P \n");
	   	  value = E;
	   	  break; /* optional */
	   case 'N'  :
	   	  //print("E \n");
	   	  value = N;
	   	  break; /* optional */
	   case 'R'  :
	   	   	  //print("E \n");
	   	   	  value = R;
	   	   	  break; /* optional */
	   case '0'	:
		   value = zero;
		   break;
	   case '1'	:
		   value = one;
		   break;
	   case '2'	:
		   value = two;
		   break;
	   case '3'	:
		   value = three;
		   break;
	   case '4'	:
		   value = four;
		   break;
	   case '5'	:
		   value = five;
		   break;
	   case '6'	:
		   value = six;
		   break;
	   case '7'	:
		   value = seven;
		   break;
	   case '8'	:
		   value = eight;
		   break;
	   case '9'	:
		   value = nine;
		   break;
	   /* you can have any number of case statements */
	   default : /* Optional */
	   //print("other \n");
	   value = 0x00;
	}
	//putnum(value);
	return value;
}
/******************************************************************************/

int * display_String(char *text){
	static int text_to_number[4];
	text_to_number[0] = display_Character(*text);
	text_to_number[1] = display_Character(*(text+1));
	text_to_number[2] = display_Character(*(text+2));
	text_to_number[3] = display_Character(*(text+3));
	print("\n");
	//putnum(text_to_number[0]);
	return text_to_number;
}

int display_Segment(char *text, int time)
{
	int Status;
	volatile int Delay;
	volatile int t=0;
	int *text_to_number;
	text_to_number = display_String(text);
	putnum((*text_to_number));
	putnum((*(text_to_number+1)));
	putnum((*(text_to_number+2)));
	putnum((*(text_to_number+3)));
	print("\n");
	/* Initialize the GPIO driver */
	Status = XGpio_Initialize(&Gpio, XPAR_GPIO_0_DEVICE_ID);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}
	/* Set the direction for all signals as outputs for LEDs */
	XGpio_SetDataDirection(&Gpio, LED_ANODE, 0x0);
	/* Loop forever blinking the LED */
	while (t<time) {
		XGpio_DiscreteWrite(&Gpio, LED_ANODE, 0x0E);
		XGpio_DiscreteWrite(&Gpio, LED_CHARACTER, *(text_to_number+3)); //Display 0
		for (Delay = 0; Delay < LED_DELAY; Delay++);
		XGpio_DiscreteWrite(&Gpio, LED_ANODE, 0x0D);
		XGpio_DiscreteWrite(&Gpio, LED_CHARACTER, *(text_to_number+2)); //Display 1
		for (Delay = 0; Delay < LED_DELAY; Delay++);
		XGpio_DiscreteWrite(&Gpio, LED_ANODE, 0x0B);
		XGpio_DiscreteWrite(&Gpio, LED_CHARACTER, *(text_to_number+1)); //Display 2
		for (Delay = 0; Delay < LED_DELAY; Delay++);
		XGpio_DiscreteWrite(&Gpio, LED_ANODE, 0x07);
		XGpio_DiscreteWrite(&Gpio, LED_CHARACTER, *text_to_number); //Display 3
		for (Delay = 0; Delay < LED_DELAY; Delay++);
		t = t+1;
	}
	return XST_SUCCESS;
}

int init_switches(){
	int Status;
	/* Initialize the GPIO driver */
	Status = XGpio_Initialize(&Gpio1, XPAR_GPIO_1_DEVICE_ID);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}
	XGpio_SetDataDirection(&Gpio1, 1, 0xff); //Push Buttons
	XGpio_SetDataDirection(&Gpio1, 2, 0xff); //Switches
	return 0;
}

int main()
{
	//Password verification main deleted to implement Hill Decoder main
	//-----------------------------------------------------------------

	//Hill decoder main

	//Initialize and process provided methods
	init_switches();//Activating GPIO driver to use buttons and switches
	init_platform();//Activating GPIO driver to use displays (0 to 3) => 4 displays

	//Console initialize header
	Encrypt();
	//Clean platform();
	return 0;
}

//---------------------------------------------------------------------------------------------
//Hill Cipher base code in C++ (Just testing) => Test Failed

/*int d,x,y;
 int x1,x2,y1,y2;
 int q,r;
 int *rpts=new int[3];

 if(b==0){
  d=a;
  x=1;
  y=0;

  rpts[0]=d; rpts[1]=x; rpts[2]=y;
  return rpts;
 }
 x1=0; x2=1;
 y1=1; y2=0;
 while(b >0){
  q=(a/b); r=a-q*b;
  x=x2-q*x1; y=y2-q*y1;
  a=b; b=r;
  x2=x1; x1=x;
  y2=y1; y1=y;
 }
 //d=a;
 rpts[0]=a; rpts[1]=x2; rpts[2]=y2;

 return rpts;
}

void multiplicarMatriz(int M[][100],int P[][100], int C[][100], int m,int p,int n){
 int s;

 for (int i=0;i< m;i++){
  for(int j=0;j< n;j++){
   s=0;
   for(int k=0;k< p;k++){
    s+=M[i][k]*P[k][j];
   }
   C[i][j]=s;
  }
 }
}

while(k< =tam){
   if(p< d){
    P[p][0]=textAgru[k]-97;
    //cout< < P[p][0]< < " " ;
    p++;
   }else{
    multiplicarMatriz(M,P,C,d,p,1);
    for(int i=ini;i< k;i++){
     textAgru[i]=(C[m][0]%26)+97;
     m++;
    }
    ini=k+1;
    m=0;
    p=0;
   }
   k++;
  }
  cout< < "\n\t\tTexto Encriptado: "< < textAgru;
 }else
  cout< < "\n\t\tCon la clave matrices ingresada no se puede encriptar el mensaje";
}*/
//---------------------------------------------------------------------------------------------

void Encrypt(){
	//Validating sizes before enter the Hill Cipher method

	//Ask user for data
	print("Type a valid 3x3 matrix: \n");//The console will receive data constantly, but it
											  //will be processed as a 3 rows * 3 columns matrix

	//Take in consideration that the algorithm assigns each letter a number in its respective order
	//in the alphabet (26 letters)
		for(i=0; i<3; i++){//validating that the maximum size is 3
			for(j=0; j<3; j++){//validating that the maximum size is 3
				scanf("%i", &A[i][j]);//C General Syntaxes --> "scanf" = Scan Format (Standard Program Flow)
									  //C General Syntaxes --> "%i" = Type --> Indicator type
									  //C General Syntaxes --> & (Ampersand) = Indicates a memory address where the data will be saved
				C[i][j] = A[i][j];
			}
		}
	//Ask user for a valid string that will be encrypted
	print("\nType a valid 3-letter string: \n");
	scanf("%s", &Output);//C General Syntaxes --> "%s" = string of characters --> Indicator type
		for(i=0; i<3; i++){//The console will receive data constantly, but it
			               //will be processed as a 3 position vector.
			BC[i][0] = Output[i]-97;
		}
	//Ask user to push a button to encrypt the message (vector)
	print("\nPress the left button to encrypt\n");
		//While it is any button pushed, the algorithm will stay freeze.
		while(button == 0){
			button = XGpio_DiscreteRead(&Gpio1, 1);//Gpio1 declared in the provided code above.
		}
		//After user press the button, the Hill Cipher algorithm takes place
		if(button == 2){//Evaluates it the channel of the button is the #2
			for(i=0; i<3; i++){
				for(j=0; j<1; j++){
					for(k=0; k<3; k++){
						encrypt[i][j] = encrypt[i][j] + A[i][k] * BC[k][j];//Encrypt rows and columns (Add and multiply)
				}
			}
		}
	//Show the Encrypted string in console
	print("\nThe encrypted word is: \n");
		for(i=0; i<3; i++){
			newCode = (encrypt[i][0]%26)+97;
			print((char)newCode);//Print in console the new generated code after running the cipher
		}
	}
}
